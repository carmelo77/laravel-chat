<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Laravel chat</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="<?php echo e(url('/css/app.css')); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
  </head>
  <body>
    <div id="app" class="container">
      <div class="row-fluid">
        <div class="col-md-12">
          <h1>Conected: <?php echo e(Auth::user()->name); ?></h1>
        </div>
        <contacts></contacts>
        <messages></messages>
      </div>
    </div>
    <!-- Latest compiled and minified JavaScript -->
    <script src="<?php echo e(url('/js/app.js')); ?>"></script>
    <script src="<?php echo e(url('/')); ?>/scripts/socket.js" type="text/javascript"></script>
    <script>
        var socket = io('http://localhost:3000/');
    </script>
  </body>
</html>
